#ifndef __BUZZER_H__
#define __BUZZER_H__

void Buzzer_Tinme(unsigned int ms);

#endif