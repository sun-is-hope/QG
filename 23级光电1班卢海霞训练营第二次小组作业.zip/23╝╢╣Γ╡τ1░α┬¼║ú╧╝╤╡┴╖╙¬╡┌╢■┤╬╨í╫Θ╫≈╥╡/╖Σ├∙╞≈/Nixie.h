#ifndef __NIXIE_H_
#define __NIXIE_H_

void Nixie(unsigned char Location,Number);

#endif